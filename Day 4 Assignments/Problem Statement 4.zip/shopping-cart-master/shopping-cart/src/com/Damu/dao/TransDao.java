package com.damu.dao;

public interface TransDao {

	public String getUserId(String transId);
}
